package com.example.swimmasterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
